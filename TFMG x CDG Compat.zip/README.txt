﻿=== TFMG x CDG Compat ===

Kompatibilität zwischen Create Diesel Generators (CDG) und The Factory Must Grow (TFMG) für NeoForge 1.21.1.

=== Features ==="

- Rohöl, Diesel, Benzin: bidirektionale Konvertierung (Bucket + Fluid)
- Kerosin: CDG Diesel → TFMG Kerosin (Cracking 150→100mB)
- E10 Bio-Fuel: CDG Ethanol + TFMG Benzin → 2× Benzin
- Biodiesel Blend: CDG Diesel/Biodiesel → 2× Diesel (beide Richtungen)
- Naphtha Stretch: Diesel + 10% Naphtha → +10% Diesel (beide Richtungen)
- CDG Fuels in TFMG Flammenwerfer/Feuerbüchsen
- Fix für create_netherless 'fluid_stack'-Parsefehler (8 Rezepte)

=== Installation ==="

1. KubeJS muss installiert sein
2. kubejs/-Ordner ins Modpack entpacken (überschreibt bestehende Dateien)
3. Server neustarten

=== Voraussetzungen (Modpack) ==="

- KubeJS (immer)
- createdieselgenerators + tfmg (für cdg_tfmg_compat.js)
- create_netherless (für die Rezept-Fixes, optional)

=== Lizenz ==="

MIT - frei verwendbar, kopierbar, modifizierbar.
