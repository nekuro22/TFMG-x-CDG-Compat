=== create_netherless_fix v1 ===

Fix für create_netherless-Rezept-Errors unter KubeJS + NeoForge 1.21.1.
Ersetzt das alte "fluid_stack"-Format durch das korrekte "neoforge:single"-Format.

=== Enthaltene Dateien ===

kubejs/server_scripts/
  cdg_tfmg_compat.js          ← CDG↔TFMG Fuel-Kompatibilität (optional)
  create_netherless_fix.js    ← Status-Log (optional, nur Info)

kubejs/data/pack.mcmeta                      ← Data-Pack-Manifest
kubejs/data/create_netherless/recipe/        ← 8 korrigierte Rezepte

=== Installation ===

1. KubeJS und create_netherless müssen im Modpack installiert sein
2. Das gesamte kubejs/-Verzeichnis in den Modpack-Ordner entpacken
   (überschreibt existierende kubejs/server_scripts/ usw.)
3. Modpack/Server neustarten

=== Voraussetzungen ===

- Minecraft NeoForge 1.21.1
- KubeJS (beliebige Version für 1.21.1)
- create_netherless (für die Rezept-Fixes)
- CDG + TFMG (optional, nur für cdg_tfmg_compat.js)

=== Lizenz ===

MIT – frei verwendbar, kopierbar, modifizierbar.
