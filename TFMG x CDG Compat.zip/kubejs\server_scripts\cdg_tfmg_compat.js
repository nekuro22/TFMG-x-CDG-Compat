// Crude Oil Compatibility between Create Diesel Generators (CDG) and The Factory Must Grow (TFMG)
// Loads only when both mods are present.
// License: MIT – free to use, share, and modify.

const CDG = 'createdieselgenerators'
const TFMG = 'tfmg'
const NS = 'cdg_tfmg_compat'

ServerEvents.recipes(event => {
  if (!Platform.isLoaded(CDG) || !Platform.isLoaded(TFMG)) {
    console.warn(`[${NS}] Skipped – missing ${!Platform.isLoaded(CDG) ? CDG : TFMG}`)
    return
  }

  // ============================================================
  // 1. BUCKET CONVERSION — Crafting Table (shapeless, 1:1)
  // ============================================================

  event.shapeless(
    `${TFMG}:crude_oil_bucket`,
    [`${CDG}:crude_oil_bucket`]
  ).id(`${NS}:cdg_crude_bucket_to_tfmg`)

  event.shapeless(
    `${CDG}:crude_oil_bucket`,
    [`${TFMG}:crude_oil_bucket`]
  ).id(`${NS}:tfmg_crude_bucket_to_cdg`)

  // ============================================================
  // 2. FLUID CONVERSION — Create Mixing (1:1, instant, no heat)
  // ============================================================

  event.recipes.create.mixing(
    Fluid.of(`${TFMG}:crude_oil`, 100),
    [Fluid.of(`${CDG}:crude_oil`, 100)]
  ).id(`${NS}:cdg_crude_fluid_to_tfmg`)

  event.recipes.create.mixing(
    Fluid.of(`${CDG}:crude_oil`, 100),
    [Fluid.of(`${TFMG}:crude_oil`, 100)]
  ).id(`${NS}:tfmg_crude_fluid_to_cdg`)

  // ============================================================
  // 3. BUCKET CONVERSION — Diesel
  // ============================================================

  event.shapeless(
    `${TFMG}:diesel_bucket`,
    [`${CDG}:diesel_bucket`]
  ).id(`${NS}:cdg_diesel_bucket_to_tfmg`)

  event.shapeless(
    `${CDG}:diesel_bucket`,
    [`${TFMG}:diesel_bucket`]
  ).id(`${NS}:tfmg_diesel_bucket_to_cdg`)

  // ============================================================
  // 4. FLUID CONVERSION — Diesel
  // ============================================================

  event.recipes.create.mixing(
    Fluid.of(`${TFMG}:diesel`, 100),
    [Fluid.of(`${CDG}:diesel`, 100)]
  ).id(`${NS}:cdg_diesel_fluid_to_tfmg`)

  event.recipes.create.mixing(
    Fluid.of(`${CDG}:diesel`, 100),
    [Fluid.of(`${TFMG}:diesel`, 100)]
  ).id(`${NS}:tfmg_diesel_fluid_to_cdg`)

  // ============================================================
  // 5. BUCKET CONVERSION — Gasoline
  // ============================================================

  event.shapeless(
    `${TFMG}:gasoline_bucket`,
    [`${CDG}:gasoline_bucket`]
  ).id(`${NS}:cdg_gasoline_bucket_to_tfmg`)

  event.shapeless(
    `${CDG}:gasoline_bucket`,
    [`${TFMG}:gasoline_bucket`]
  ).id(`${NS}:tfmg_gasoline_bucket_to_cdg`)

  // ============================================================
  // 6. FLUID CONVERSION — Gasoline
  // ============================================================

  event.recipes.create.mixing(
    Fluid.of(`${TFMG}:gasoline`, 100),
    [Fluid.of(`${CDG}:gasoline`, 100)]
  ).id(`${NS}:cdg_gasoline_fluid_to_tfmg`)

  event.recipes.create.mixing(
    Fluid.of(`${CDG}:gasoline`, 100),
    [Fluid.of(`${TFMG}:gasoline`, 100)]
  ).id(`${NS}:tfmg_gasoline_fluid_to_cdg`)

  // ============================================================
  // 7. KEROSENE — one-way conversion via diesel cracking
  //    CDG doesn't have kerosene, so CDG diesel → TFMG kerosene
  // ============================================================

  event.shapeless(
    `${TFMG}:kerosene_bucket`,
    [`${CDG}:diesel_bucket`]
  ).id(`${NS}:cdg_diesel_bucket_to_tfmg_kerosene`)

  event.recipes.create.mixing(
    Fluid.of(`${TFMG}:kerosene`, 100),
    [Fluid.of(`${CDG}:diesel`, 150)]
  ).id(`${NS}:cdg_diesel_fluid_to_tfmg_kerosene`)

  console.info(`[${NS}] Loaded – CDG ↔ TFMG crude oil, diesel, gasoline, kerosene recipes registered`)
})

// ============================================================
// FUEL TAG COMPATIBILITY — TFMG flamethrower & firebox
// ============================================================

ServerEvents.tags('fluid', event => {
  if (!Platform.isLoaded(CDG) || !Platform.isLoaded(TFMG)) return

  // CDG diesel/gasoline/crude → TFMG flamethrower fuel
  event.add('tfmg:flammable', [
    `${CDG}:diesel`,
    `${CDG}:flowing_diesel`,
    `${CDG}:gasoline`,
    `${CDG}:flowing_gasoline`,
    `${CDG}:crude_oil`,
  ])

  // CDG diesel → TFMG firebox fuel (kerosene heater etc.)
  event.add('tfmg:firebox_fuel', [
    `${CDG}:diesel`,
    `${CDG}:flowing_diesel`,
  ])

  console.info(`[${NS}] Tags updated – CDG fuels added to TFMG flammable/firebox tags`)
})
