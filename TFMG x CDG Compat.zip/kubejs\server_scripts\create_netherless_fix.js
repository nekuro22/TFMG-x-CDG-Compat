// create_netherless recipes with 'fluid_stack' type are overridden via kubejs/data/
// to use 'neoforge:single' – the correct NeoForge fluid ingredient format.
// This prevents KubeJS parse errors. All original recipe IDs are preserved.

const CN = 'create_netherless'
const CN_NS = 'create_netherless_fix'

ServerEvents.recipes(event => {
  if (!Platform.isLoaded(CN)) return

  // The transitional sub-recipe 'incomplete_blaze_rod' is auto-generated
  // from the sequenced assembly. The data override already provides the
  // correct format, so no removal is needed.
})

console.info(`[${CN_NS}] Active – 7 recipe data overrides loaded for ${CN}`)
